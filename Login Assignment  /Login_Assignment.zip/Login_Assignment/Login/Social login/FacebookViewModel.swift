//
//  FacebookViewModel.swift
//  Login
//
//  Created by Ashfaque Tamboli
//  Copyright © 2018 Ashfaque Tamboli. All rights reserved.
//

import Foundation
import FBSDKLoginKit
import Firebase
class FacebookViewModel {
    
   
    func facebookLogin(handler completion : @escaping (Dictionary<String,Any>)->())  {
        
        let fbLoginManager = FBSDKLoginManager()
        fbLoginManager.logIn(withReadPermissions: ["public_profile", "email"], from: nil) { (result, error) in
            if let error = error {
                print("Failed to login: \(error.localizedDescription)")
                return
            }
            
            guard let accessToken = FBSDKAccessToken.current() else {
                print("Failed to get access token")
                return
            }
            
            let credential = FacebookAuthProvider.credential(withAccessToken: accessToken.tokenString)
            
            // Perform login by calling Firebase APIs
            Auth.auth().signIn(with: credential, completion: { (user, error) in
                if let error = error {
                    
                    let errorDict = ["msg":error.localizedDescription,
                        "status": "fail"]
                    completion(errorDict)
                    
                    print("Login error: \(error.localizedDescription)")
                   
                    
                    return
                }
                let sucessDict = ["msg":"\(String(describing: user))" + "login sucessfully",
                 "status": "sucess"]
                
                completion(sucessDict)

                
            })
            
        }
    }
    
}
