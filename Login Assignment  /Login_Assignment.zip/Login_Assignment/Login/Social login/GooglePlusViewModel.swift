//
//  GooglePlusViewModel.swift
//  Login
//
//  Created by Ashfaque Tamboli.
//  Copyright © 2018 Ashfaque Tamboli. All rights reserved.
//

import Foundation
import Firebase
import GoogleSignIn
class GooglePlusViewModel:NSObject,GIDSignInUIDelegate,GIDSignInDelegate {
    var onUpdate: ((Dictionary<String,Any>)->())?
  
    func goolePlusLogin() {
        
        GIDSignIn.sharedInstance().delegate = self
        GIDSignIn.sharedInstance().uiDelegate = self
        GIDSignIn.sharedInstance().signIn()
        
    }
    
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error?) {
        // ...
        if let error = error {
           
            let errorDict = ["msg":error.localizedDescription,
                             "status": "fail"]
            onUpdate?(errorDict)
            return
        }
        
        guard let authentication = user.authentication else { return }
        let credential = GoogleAuthProvider.credential(withIDToken: authentication.idToken,
                                                       accessToken: authentication.accessToken)
        
        Auth.auth().signIn(with: credential) { (user, error) in
            if let error = error {
                let errorDict = ["msg":error.localizedDescription,
                                 "status": "fail"]
                self.onUpdate?(errorDict)
                return
            }
            let sucessDict = ["msg": "login sucessfully",
                              "status": "sucess"]
            self.onUpdate?(sucessDict)
        }
        
    }
    
    func sign(_ signIn: GIDSignIn!, didDisconnectWith user: GIDGoogleUser!, withError error: Error!) {
        
        let errorDict = ["msg":error.localizedDescription,
                         "status": "fail"]
        onUpdate?(errorDict)
    }
    
    func sign(_ signIn: GIDSignIn!, dismiss viewController: UIViewController!) {
        
    }
    func sign(_ signIn: GIDSignIn!, present viewController: UIViewController!) {
        
    }
}


