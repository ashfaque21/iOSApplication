//
//  TwitterViewModel.swift
//  Login
//
//  Created by Ashfaque Tamboli.
//  Copyright © 2018 Ashfaque Tamboli. All rights reserved.
//

import Foundation
import TwitterKit
import Firebase
class TwitterViewModel {
    
    
    func twitterLogin(handler completion : @escaping (Dictionary<String,Any>)->())  {
        
        Twitter.sharedInstance().logIn() { (session, error) in
            if let session = session {
                // [START headless_twitter_auth]
                let credential = TwitterAuthProvider.credential(withToken: session.authToken, secret: session.authTokenSecret)
                
                
                if let user = Auth.auth().currentUser {
                    
                    user.link(with: credential) { (user, error) in
                        
                        
                        if let error = error {
                            
                            let errorDict = ["msg":error.localizedDescription,
                                             "status": "fail"]
                            completion(errorDict)
                            
                            print("Login error: \(error.localizedDescription)")
                            return
                        }
                    }
                    
                } else {
                    
                    Auth.auth().signIn(with: credential) { (user, error) in
                        
                        if let error = error {
                            let errorDict = ["msg":error.localizedDescription,
                                             "status": "fail"]
                            completion(errorDict)
                            
                            print("Login error: \(error.localizedDescription)")
                            return
                        }
                        
                    }
                }
               
                let sucessDict = ["msg": "login sucessfully",
                                  "status": "sucess"]
                
                completion(sucessDict)
                
            } else {
                
                if let error = error {
                    
                    let errorDict = ["msg":error.localizedDescription,
                                     "status": "fail"]
                    completion(errorDict)
                    
                    print("Login error: \(error.localizedDescription)")
                    return
                }
                
            }
        }
    

    }
   


}
