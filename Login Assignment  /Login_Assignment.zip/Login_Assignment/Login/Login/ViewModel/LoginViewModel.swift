//
//  LoginViewModel.swift
//  Login
//
//  Created by Ashfaque Tamboli.
//  Copyright © 2018 Ashfaque Tamboli. All rights reserved.
//

import Foundation
class LoginViewModel {
    
    var loginDataProvider = LoginDataProvider()
    var onCompleteParsing: ((_ result: Array<Any> )->())?
   
    var onSucess: (()->())?
    var onFail: (()->())?
    var onWrongUserNameInput : (()->())?
    var onWrongPasswordInput : (()->())?
    
    func login(data : Login) {
        guard loginValidation(data: data) else {
            self.onFail?()
            return
        }
        loginDataProvider.loginRequest(login_data: data) {result in
          if let status = result["status"] as? Bool {
                if status {
                    self.onSucess?()
                }else {
                   self.onFail?()
                }
            }else {
                self.onFail?()
            }
         }
    }
    
    func loginValidation(data : Login) -> Bool {
        guard !(data.userName?.isEmpty)! else {
            self.onWrongUserNameInput?()
            return false
        }
        guard isPasswordValid(data.password!) else{
            self.onWrongPasswordInput?()
            return false
        }
        return true
    }
    
    func isPasswordValid(_ password : String) -> Bool{
        if !password.isEmpty && password.count >= 6 {
            return true
        }
        self.onWrongPasswordInput?()
        return false
    }
}
