//
//  Login.swift
//  Login
//
//  Created by Ashfaque Tamboli
//  Copyright © 2018 Ashfaque Tamboli. All rights reserved.
//

import Foundation

struct Login {
    //default initilizer
    var userName : String?
    var password : String?
    
    init(userName : String, password : String) {
        self.userName = userName
        self.password = password
    }
    
}

