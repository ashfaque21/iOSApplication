//
//  LoginDataProvider.swift
//  Login
//
//  Created by Ashfaque Tamboli.
//  Copyright © 2018 Ashfaque Tamboli. All rights reserved.
//

import Foundation

struct LoginDataProvider {
    
    func loginRequest(login_data : Login ,handler completion : (Dictionary<String , Any>)->()){
        
        //call API to check authentication
     
            if let path = Bundle.main.path(forResource: "LoginRequest", ofType: "json") {
                do {
                    let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .alwaysMapped)
                    //parsing the Data
                    do {
                        let object = try JSONSerialization.jsonObject(with: data, options: .allowFragments)
                        if let dictionary = object as? [String: AnyObject] {
                            
                            let resultarray =
                                dictionary["AuthenticateUsers"] as? [[String: AnyObject]]
                            var isFound = false
                            for dictUser in resultarray! {
                                
                                if dictUser["name"] as? String == login_data.userName && dictUser["password"] as? String == login_data.password {
                                    
                                    isFound = true
                                    break
                                }else {
                                    isFound = false
                                }
                                
                                print("\(dictUser)")
                            }
                            
                            var response = [String: Bool]()
                            if isFound {
                                response["status"] = true
                            }else {
                                response["status"] = false
                            }
                            completion(response)
                           }
                    } catch let error{
                        print(error.localizedDescription)
                    }
                }catch let error{
                    print(error.localizedDescription)
                }
            }
        }
}
        
      


