//
//  LoginViewController.swift
//  Login
//
//  Created by Ashfaque Tamboli.
//  Copyright © 2018 Ashfaque Tamboli. All rights reserved.
//

import UIKit
import GoogleSignIn
import Firebase
class LoginViewController: UIViewController {
    
    //IB-Outlet
    
    @IBOutlet var loginTitleLabel: UILabel!
    @IBOutlet var userNameLabel: UILabel!
    
    @IBOutlet var userNameTextField: UITextField!
    @IBOutlet var passwordLabel: UILabel!
    @IBOutlet var passwordTextField: UITextField!
    
    var loginViewModel = LoginViewModel()
    var fbLogin = FacebookViewModel()
    var twiiterLogin = TwitterViewModel()
    var googlePluseLogin  = GooglePlusViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        userNameTextField.becomeFirstResponder()
        // Do any additional setup after loading the view, typically from a nib.
        self.loginErrorHandling()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        userNameTextField.becomeFirstResponder()
    }
    override func viewDidDisappear(_ animated: Bool) {
        
        super.viewDidDisappear(animated)
        self.passwordTextField.text = ""
        self.userNameTextField.text = ""
        
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

   
    @IBAction func loginButtonClicked(_ sender: UIButton) {
        
        let loginModel = Login(userName: self.userNameTextField.text!, password: self.passwordTextField.text!)
        loginViewModel.login(data: loginModel)
    }
    
    @IBAction func forgotPasswordButtonClicked(_ sender: UIButton) {
        //TODO :: Forgot Password code handling should be handled.
        self.showAlert(message: "Forgot Password Button Clicked.")
    }
    
    @IBAction func facebookButtonClicked(_ sender: UIButton) {
        fbLogin.facebookLogin { response in
            self.updateUser(response)
        }
    }
    
    
    @IBAction func twitterButtonClicked(_ sender: UIButton) {
        twiiterLogin.twitterLogin { (response) in
            self.updateUser(response)
        }
    }
    
    
    @IBAction func googlePlusButtonClicked(_ sender: UIButton) {
        googlePluseLogin.onUpdate = { response in
             self.updateUser(response)
        }
        googlePluseLogin.goolePlusLogin()
    }
}


extension LoginViewController {
    
    func navigateToDashboard()  {

        self.performSegue(withIdentifier: "ShowDashboard", sender: self)
        
    }
    func showAlert(message msg : String)  {
        let alertView = UIAlertController(title: "Alert", message: msg, preferredStyle: .alert)
        alertView.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        present(alertView, animated: true, completion: nil)
    }
    
    func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        super.prepare(for: segue, sender: sender)
        if segue.identifier == "ShowDashboard"
        {
            if segue.destination is DashboardViewController {
            }
        }
    }
    
   private func updateUser(_ response : Dictionary<String, Any>)  {
        if let status = response["status"] as? String  {
            if (status == "sucess") {
                self.navigateToDashboard()
            }else {
                if let msg = response["msg"] as? String {
                    self.showAlert(message: msg)
                }
                self.showAlert(message: "cannot login")
            }
        }
    }
    
    private func loginErrorHandling() {
        
        loginViewModel.onSucess = {
            self.navigateToDashboard()
        }
        loginViewModel.onFail = {
            self.showAlert(message: "Oops!!! Either your User name or password is wrong.")
        }
        loginViewModel.onWrongUserNameInput = {
            self.showAlert(message: "UserName should not be wrong.")
        }
        loginViewModel.onWrongPasswordInput = {
            self.showAlert(message: "Password should not be empty or wrong.")
        }
    }
}
    

