//
//  Login.swift
//  UnitTest
//
//  Created by Ashfaque Tamboli.
//  Copyright © 2018 Ashfaque Tamboli. All rights reserved.
//

import Foundation

struct Login {
    var userName : String?
    var password : String?
    
    init() {
        
    }
    
    init(userName : String?, password : String?) {
        self.userName = userName
        self.password = password
    }
    
    func isUserNameNil(userName : String?) -> Bool {
        guard let _ = userName else {
            return false
        }
        return true
    }
    
    func isUserNameLength(userName : String?) -> Bool {
        var returnValue = false
        if let length = userName?.count {
            if length >= 5 {
                returnValue = true
            }
            else {
                returnValue = false
            }
        }
        return returnValue
    }
    
    func isPasswordNil(password:String?) -> Bool {
        guard let _ = password else {
            return false
        }
        return true
    }
    
    func isPasswordLength(password : String?) -> Bool {
        var returnValue = false
        if let length = password?.count {
            if length >= 6 {
            returnValue = true
        }
        else
        {
            returnValue = false
        }
        }
        return returnValue
    }
    
    func checkModuleValidations(loginModel : Login?) -> Bool {
        var returnValue = false
        
        guard let userName = loginModel?.userName, let passWord = loginModel?.password else {
            return returnValue
        }
        if (isUserNameLength(userName: userName) && isPasswordLength(password: passWord)) {
            returnValue = true
        }
        
        return returnValue
    }
}
