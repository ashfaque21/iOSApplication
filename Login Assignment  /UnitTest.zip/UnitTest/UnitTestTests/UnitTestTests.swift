//
//  UnitTestTests.swift
//  UnitTestTests
//
//  Created by Aahil Tamboli on 29/03/18.
//  Copyright © 2018 Ashfaque Tamboli. All rights reserved.
//

import XCTest
@testable import UnitTest

class UnitTestTests: XCTestCase {
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testNilCondition() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
        let loginModel = Login()
        
       XCTAssertFalse(loginModel.isUserNameNil(userName: loginModel.userName))
       XCTAssertFalse(loginModel.isPasswordNil(password: loginModel.password))
       XCTAssertFalse(loginModel.isPasswordLength(password: loginModel.password))
    }
    
    func testUserNameValidations() {
        var loginModel = Login(userName: "Ashfaque", password: "")
        XCTAssertTrue(loginModel.isUserNameNil(userName: loginModel.userName))
        loginModel.userName = "Ash"
        XCTAssertFalse(loginModel.isUserNameLength(userName: loginModel.userName))
        loginModel.userName = "Maharashtra"
        XCTAssertTrue(loginModel.isUserNameLength(userName: loginModel.userName))
    }
    
    func testPasswordValidations() {
        var loginModel = Login(userName: "", password: "123456")
        XCTAssertTrue(loginModel.isPasswordLength(password: loginModel.password))
        loginModel.password = "123"
        XCTAssertTrue(loginModel.isPasswordLength(password: loginModel.password))
        loginModel.password = "12345678"
        XCTAssertTrue(loginModel.isPasswordLength(password: loginModel.password))
    }
   
    func testLoginValiations() {
        var loginModel = Login(userName: "Ashfaque", password: "1234567")
        XCTAssertTrue(loginModel.checkModuleValidations(loginModel: loginModel))
        loginModel = Login(userName: "Ash", password: "123")
        XCTAssertFalse(loginModel.checkModuleValidations(loginModel: loginModel))
    }
    
}
